20.4.2022.

Zavrsni rad za PHP programera u Edunovi u sklopu grupe PP24.

Rad je pisan u MVC frameworku. U rad je implementirano nekoliko PHP i Javascript aplikacija. 
Uz Foundation,koristio sam i vlastiti  CSS kod za design.
